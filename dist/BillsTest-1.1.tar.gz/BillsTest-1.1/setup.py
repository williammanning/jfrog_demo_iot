#!/usr/bin/env python

from distutils.core import setup

setup(name='BillsTest',
      version='1.1',
      description='Bills iOT Test',
      author='Bill Manning',
      author_email='billm@jfrog.com'
     )
